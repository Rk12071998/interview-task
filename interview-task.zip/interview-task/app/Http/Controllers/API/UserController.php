<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        try {
            $userList = User::with('getRole')->orderBy('id', 'desc')->get();
            if ($userList->isEmpty())
            {
                return response()->json(['success' => true, 'message' => 'Data does not exist.', 'data' => ''], 404);
            }
            return response()->json(['success' => true, 'message' => 'User list.', 'data' => $userList], 200);
        } catch (Exception $e) {
            return response()->json(['error' => true, 'message' => $e->getMessage()], 500);
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $data = $request->all();

            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:255',
                'email' => 'required|email|unique:users,email',
                'phone' => 'required|regex:/^[6-9][0-9]{9}$/|unique:users,phone',
                'role_id' => 'required|exists:roles,id',
                'description' => 'nullable|string',
                'profile_image' => 'required|image|mimes:jpeg,jpg,png,svg,gif',
            ]);

            if ($validator->fails()) {
                return response()->json(['errors' => $validator->errors()], 422);
            }            

            $profileImageName = '';
            if ($request->hasFile('profile_image')) {
                $profileImageName = time().'_'.mt_rand(1000000, 9999999).'.'.$request->profile_image->extension();
                $request->profile_image->move(public_path('profile_images'), $profileImageName);
            }

            $user = new User();
            $user->name = $request->name;
            $user->email = $request->email;
            $user->phone = $request->phone;
            $user->role_id = $request->role_id;
            $user->description = $request->description;
            $user->profile_image = $profileImageName;
            $user->save();

            return response()->json(['success' => true, 'message' => 'User added successfully.', 'data' => $user], 200);
        } catch (Exception $e) {
            return response()->json(['error' => true, 'message' => $e->getMessage()], 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
