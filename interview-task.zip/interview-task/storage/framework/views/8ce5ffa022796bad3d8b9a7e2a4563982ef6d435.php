<!DOCTYPE html>
<html>

<head>
    <title>User Form Task</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
</head>

<body>
    <div class="container mt-5">
        <div id="user_form">
            <h2>User Form</h2>

            <p class="p-btn" id="userTableShow">
                <button class="btn btn-primary float-right">User Table</button>
            </p>
            <form id="userForm" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label>Name:</label>
                            <input type="text" id="name" name="name" class="form-control">
                            <span id="name_error"></span>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label>Email:</label>
                            <input type="email" id="email" name="email" class="form-control">
                            <span id="email_error"></span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label>Phone:</label>
                            <input type="text" id="phone" name="phone" class="form-control"
                                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"
                                maxlength="10">
                            <span id="phone_error"></span>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label>Role:</label>
                            <select id="role_id" name="role_id" class="form-control">
                                <option value="">Please Select</option>
                                <?php if(!$roles->isEmpty()): ?>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <option value="" disabled>Data not found</option>
                                <?php endif; ?>
                            </select>
                            <span id="role_error"></span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label>Profile Image:</label>
                            <input type="file" id="profile_image" name="profile_image" class="form-control">
                            <span id="profile_error"></span>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label>Description:</label>
                            <textarea id="description" name="description" class="form-control"></textarea>
                            <span id="description_error"></span>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>

        <div id="user_table">
            <h2 class="mt-5">Users Table</h2>
            <p class="p-btn" id="userFormShow">
                <button class="btn btn-primary float-right">User Table</button>
            </p>
            <table class="table table-bordered" id="userTable">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Description</th>
                        <th>Role</th>
                        <th>Profile Image</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="<?php echo e(asset('js/user-form.js')); ?>"></script>
    <script>
    $(document).ready(function() {
        $("#userTableShow").on('click', function() {
            $('#user_form').hide();
            $('#user_table').show();
            fetchUsers();
        });

        $("#userFormShow").on('click', function() {
            $('#user_form').show();
            $('#user_table').hide();
        });

        $('#userForm').submit(function(e) {
            e.preventDefault();

            var formData = new FormData(this);
            console.log(formData);

            let name = $("#name").val();
            let email = $("#email").val();
            let phone = $("#phone").val();
            let role_id = $("#role_id").val();
            let profile_image = $("#profile_image").val();
            let description = $("#description").val();

            if (description == '') {
                $("#description_error").html('This field is required.').show();
            }

            if (name == '') {
                $("#name_error").html('This field is required.').show();
            }

            if (phone == '') {
                $("#phone_error").html('This field is required.').show();
            }

            if (role_id == '') {
                $("#role_error").html('This field is required.').show();
            }

            if (profile_image == '') {
                $("#profile_error").html('This field is required.').show();
            }

            if (email == '') {
                $("#email_error").html('This field is required.').show();
            }

            if (name == '' || email == '' || phone == '' || role_id == '' || profile_image == '' ||
                description == '') {
                return false;
            }

            const emailReg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

            if (!emailReg.test(email)) {
                $("#email_error").html('Invalid Email Address.').show();
                return false;
            }

            const phoneReg = /^[6-9]{1}[0-9]{9}$/;

            if (!phoneReg.test(phone)) {
                $("#phone_error").html('Invalid phone number.').show();
                return false;
            }

            $.ajax({
                url: '<?php echo e(route("user.store")); ?>',
                method: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function(data) {
                    $('#userForm')[0].reset();

                    $("#name_error").hide();
                    $("#email_error").hide();
                    $("#phone_error").hide();
                    $("#role_error").hide();
                    $("#profile_error").hide();
                    $("#description_error").hide();

                    fetchUsers();
                    alert('User added successfully');

                    $('#user_form').hide();
                    $('#user_table').show();
                },
                error: function(xhr) {
                    var errors = xhr.responseJSON.errors;
                    var errorString = '';
                    for (var key in errors) {
                        errorString += errors[key][0] + '\n';
                    }
                    alert(errorString);
                }
            });
        });

        function fetchUsers() {
            $.get('<?php echo e(route("user.list")); ?>', function(data) {
                if (data.success == true || data.data != '') {
                    var rows = '';
                    var data = data.data;
                    console.log(data);
                    data.forEach(function(user) {
                        rows += '<tr>' +
                            '<td>' + user.name + '</td>' +
                            '<td>' + user.email + '</td>' +
                            '<td>' + user.phone + '</td>' +
                            '<td>' + user.description + '</td>' +
                            '<td>' + user.get_role.name + '</td>' +
                            '<td>' + (user.profile_image ? '<img src="/profile_images/' + user
                                .profile_image + '" width="50">' : '') + '</td>' +
                            '</tr>';
                    });
                    $('#userTable tbody').html(rows);
                }
            });
        }
    });
    </script>
</body>

</html><?php /**PATH /var/www/html/interview-task/resources/views/form.blade.php ENDPATH**/ ?>